# Resolução numérica de Equações diferenciais ordinárias

Segundo Projeto de Cálculo Numérico (MS211) do segundo semesre de 2019
Feito por:
Júlio Moreira Blás de Barros RA: 200491
Flávio Murilo Reginato RA: 197088

Matéria ministrada pelo professor João Batista Florindo
